# Command Center — Data Pipeline Deep Dive

## The Big Picture: What Your App Actually Does

Your app is the **assembler**. No other system in the org has the full picture of a use case. Each team's system holds one piece:

```
Governance API:  "UC-1042 is Approved, severity High, pending CISO sign-off"
Lifecycle Tracker: "UC-1042 is in Pilot stage, 14 days in, SLA is 30 days"
Model Monitor:   "UC-1042's model has 0.94 accuracy, 0.12 drift score"
Risk Platform:   "UC-1042 has 1 policy violation, 3 guardrail triggers"
Finance System:  "UC-1042 costs $4,200/month"
Alert System:    "UC-1042 has no active alerts"
```

Your app pulls all of these, stitches them onto a single UseCase document,
and serves that unified view to the dashboard.

---

## Entity Model

```typescript
// ── Your app's entities (you own these) ─────────────────────────

interface BusinessCase {
  businessCaseId: string;        // "BC-1042"
  title: string;                 // "Fraud Detection AI Program"
  owner: string;                 // "Jane Smith"
  lob: string;                   // "Risk"
  submittedDate: Date;
  overallStatus: string;         // derived from child use cases
}

interface UseCase {
  useCaseId: string;             // "UC-1042"  — the universal join key
  businessCaseId: string;        // "BC-1042"  — parent FK
  useCaseName: string;           // "Transaction Anomaly Model"
  aiTechnology: 'Agentic AI' | 'GenAI';

  // ── Fields owned by Governance API ──────────────────────────
  status: 'Approved' | 'Pending' | 'Rejected' | null;
  severity: 'Critical' | 'High' | 'Medium' | 'Low' | null;
  aiOnboardingStage: string | null;
  slaStatus: 'On Track' | 'At SLA Limit' | 'SLA Breached' | null;
  approvalDays: number | null;

  // ── Fields owned by Lifecycle Tracker ───────────────────────
  lifecycleStage: 'POC' | 'Pilot' | 'Production' | 'Archived' | null;
  daysInCurrentStage: number | null;
  expectedSlaDays: number | null;

  // ── Fields owned by Model Monitor ──────────────────────────
  driftScore: number | null;
  driftCategory: 'Stable' | 'Watch' | 'High Risk' | null;
  accuracy: number | null;
  latency: number | null;
  hallucinationRate: number | null;

  // ── Fields owned by Risk Platform ──────────────────────────
  criticalAlerts: number | null;
  policyViolations: number | null;
  guardrailTriggers: number | null;
  responsibleAIScore: number | null;

  // ── Fields owned by Finance System ─────────────────────────
  monthlyCost: number | null;

  // ── Fields owned by Alert System ───────────────────────────
  alertType: string | null;
  alertStatus: 'New' | 'Under Review' | 'Acknowledged' | null;
  owner: string | null;
  detectedTime: string | null;

  // ── Metadata ───────────────────────────────────────────────
  _meta: {
    createdAt: Date;
    updatedAt: Date;
    version: number;
    sources: Record<string, {
      lastSyncedAt: Date;
      fieldsOwned: string[];
      lastHash: string;
    }>;
  };
}
```

Key insight: **most fields start as `null`**. When you first create a UseCase,
you only know the core identity fields (ID, name, parent BC, technology).
The other fields get filled in as each source system is polled. The UseCase
document is progressively enriched over time.

---

## Stage 1: INGEST — Pulling Data from Source Systems

Each source system has an **adapter** — a class that knows how to talk to
that specific system and extract raw records.

```typescript
// ── The adapter contract ──────────────────────────────────────

interface SourceRecord {
  /** The ID this source uses to identify the use case.
   *  MIGHT be useCaseId, might be something else. */
  sourceIdentifier: string;

  /** The raw fields this source provides, in ITS OWN naming */
  data: Record<string, unknown>;

  /** When this data was produced */
  timestamp: Date;
}

interface BaseAdapter {
  sourceId: string;                     // "governance-api"
  fieldsOwned: string[];                // ["status", "severity", "slaStatus", ...]
  fetch(): Promise<SourceRecord[]>;     // pull data from the source
  healthCheck(): Promise<AdapterHealth>;
}
```

### Example: Governance API Adapter

The Governance API uses `businessCaseId` (not `useCaseId`) as its primary key,
and it has its own field names that don't match our schema.

```typescript
class GovernanceApiAdapter implements BaseAdapter {
  sourceId = 'governance-api';
  fieldsOwned = ['status', 'severity', 'aiOnboardingStage', 'slaStatus', 'approvalDays'];

  async fetch(): Promise<SourceRecord[]> {
    // The Governance API returns data in ITS shape, not ours
    const response = await axios.get('https://governance.internal/api/cases', {
      headers: { Authorization: `Bearer ${this.config.token}` }
    });

    // Raw response from the Governance API:
    // [
    //   {
    //     "case_ref": "BC-1042",          ← their ID (businessCaseId, not useCaseId!)
    //     "approval_status": "Approved",   ← their field name
    //     "risk_level": "High",            ← their field name
    //     "onboarding_step": "Pending CISO",
    //     "sla_state": "On Track",
    //     "days_to_approve": 22
    //   },
    //   ...
    // ]

    return response.data.map(raw => ({
      sourceIdentifier: raw.case_ref,    // "BC-1042" — this is a businessCaseId!
      data: raw,                         // pass through the raw shape
      timestamp: new Date()
    }));
  }
}
```

### Example: Model Monitor WebSocket Adapter

The Model Monitor pushes data over WebSocket using the model's deployment name
(not useCaseId, not businessCaseId — a third identifier).

```typescript
class ModelMonitorAdapter implements BaseAdapter {
  sourceId = 'model-monitor';
  fieldsOwned = ['driftScore', 'driftCategory', 'accuracy', 'latency', 'hallucinationRate'];

  async fetch(): Promise<SourceRecord[]> {
    // WebSocket messages arrive in real-time, buffered between poll cycles
    // Raw message shape:
    // {
    //   "model_name": "txn-anomaly-v2",   ← their identifier (agent/model name!)
    //   "drift": 0.12,
    //   "drift_band": "stable",
    //   "acc": 0.94,
    //   "p99_latency_ms": 120,
    //   "hallucination_pct": 0.02
    // }

    return this.messageBuffer.drain().map(msg => ({
      sourceIdentifier: msg.model_name,  // "txn-anomaly-v2" — a model name!
      data: msg,
      timestamp: new Date(msg.ts)
    }));
  }
}
```

### Example: Finance System Excel Adapter

Finance drops an Excel file monthly. The file uses a cost center code.

```typescript
class FinanceExcelAdapter implements BaseAdapter {
  sourceId = 'finance-system';
  fieldsOwned = ['monthlyCost'];

  async fetch(): Promise<SourceRecord[]> {
    // Watch for new .xlsx files in a directory
    const file = await this.getLatestFile('/data/finance-drops/');
    const workbook = xlsx.readFile(file);
    const rows = xlsx.utils.sheet_to_json(workbook.Sheets['AI Costs']);

    // Excel row shape:
    // {
    //   "Cost Center": "CC-FRAUD-01",    ← their identifier!
    //   "Monthly Spend": 4200,
    //   "Period": "2026-03"
    // }

    return rows.map(row => ({
      sourceIdentifier: row['Cost Center'],  // "CC-FRAUD-01" — a cost center!
      data: row,
      timestamp: new Date()
    }));
  }
}
```

**Notice the problem:** every source uses a different identifier.
The Governance API uses `businessCaseId`, the Model Monitor uses model name,
Finance uses cost center codes. This is realistic — you don't control these
systems.

---

## Stage 2: NORMALIZE — Resolving Identity & Mapping Fields

This is the critical stage. Two things happen:

1. **Identity resolution**: figure out which `useCaseId` this record belongs to
2. **Field mapping**: translate the source's field names to our schema

### The Identity Map

You maintain a lookup table that maps each source's native ID to your
canonical `useCaseId`:

```typescript
// ── idMappings collection in MongoDB ─────────────────────────

// One document per use case:
{
  useCaseId: "UC-1042",
  mappings: {
    "governance-api":  "BC-1042",        // Governance uses businessCaseId
    "model-monitor":   "txn-anomaly-v2", // Model Monitor uses model name
    "finance-system":  "CC-FRAUD-01",    // Finance uses cost center
    "lifecycle-tracker": "UC-1042",      // Lifecycle actually uses useCaseId!
    "risk-platform":   "UC-1042",        // Risk also uses useCaseId
    "alert-system":    "UC-1042"         // Alerts also use useCaseId
  }
}
```

**Where does this mapping come from?**
- Some of it you know upfront (the Identity Registry provides businessCaseId, useCaseId, model name)
- Some of it gets configured by teams during onboarding ("our Finance team confirms CC-FRAUD-01 maps to UC-1042")
- Some of it can be seeded from a spreadsheet
- The mapping is maintained as a living document — new mappings are added as new use cases are registered

### The Normalizer

```typescript
interface NormalizedRecord {
  useCaseId: string;                    // resolved canonical ID
  fields: Partial<UseCase>;            // mapped to OUR field names
  sourceId: string;
  timestamp: Date;
}

// Field mapping config per source (stored in sourceConfigs collection)
const SOURCE_FIELD_MAPS: Record<string, Record<string, string>> = {
  'governance-api': {
    'approval_status':  'status',
    'risk_level':       'severity',
    'onboarding_step':  'aiOnboardingStage',
    'sla_state':        'slaStatus',
    'days_to_approve':  'approvalDays',
  },
  'model-monitor': {
    'drift':              'driftScore',
    'drift_band':         'driftCategory',
    'acc':                'accuracy',
    'p99_latency_ms':     'latency',
    'hallucination_pct':  'hallucinationRate',
  },
  'finance-system': {
    'Monthly Spend': 'monthlyCost',
  },
  // ... etc for each source
};

// Value transforms (some sources use different representations)
const VALUE_TRANSFORMS: Record<string, Record<string, (v: any) => any>> = {
  'model-monitor': {
    'driftCategory': (v: string) => {
      // Model Monitor says "stable", we store "Stable"
      const map: Record<string, string> = { stable: 'Stable', watch: 'Watch', high: 'High Risk' };
      return map[v] ?? v;
    },
  },
};

async function normalize(
  sourceId: string,
  records: SourceRecord[]
): Promise<NormalizedRecord[]> {
  const fieldMap = SOURCE_FIELD_MAPS[sourceId];
  const transforms = VALUE_TRANSFORMS[sourceId] ?? {};
  const results: NormalizedRecord[] = [];

  for (const record of records) {
    // ── Step 1: Resolve identity ────────────────────────────
    const useCaseId = await resolveIdentity(sourceId, record.sourceIdentifier);

    if (!useCaseId) {
      // Can't figure out who this belongs to — dead letter it
      await db.collection('unmappedRecords').insertOne({
        sourceId,
        sourceIdentifier: record.sourceIdentifier,
        data: record.data,
        receivedAt: new Date(),
      });
      continue; // skip this record, process the rest
    }

    // ── Step 2: Map fields ──────────────────────────────────
    const fields: Record<string, unknown> = {};
    for (const [sourceField, ourField] of Object.entries(fieldMap)) {
      if (record.data[sourceField] !== undefined) {
        let value = record.data[sourceField];
        // Apply value transform if one exists
        if (transforms[ourField]) {
          value = transforms[ourField](value);
        }
        fields[ourField] = value;
      }
    }

    results.push({
      useCaseId,
      fields: fields as Partial<UseCase>,
      sourceId,
      timestamp: record.timestamp,
    });
  }

  return results;
}

async function resolveIdentity(
  sourceId: string,
  sourceIdentifier: string
): Promise<string | null> {
  // Look up: "for source 'governance-api', identifier 'BC-1042', what's the useCaseId?"
  const mapping = await db.collection('idMappings').findOne({
    [`mappings.${sourceId}`]: sourceIdentifier
  });
  return mapping?.useCaseId ?? null;
}
```

### Concrete Example: What Happens to a Governance API Record

```
Raw from source:
  { case_ref: "BC-1042", approval_status: "Approved", risk_level: "High", ... }

After identity resolution:
  useCaseId: "UC-1042"  (looked up "BC-1042" in governance-api mappings)

After field mapping:
  {
    useCaseId: "UC-1042",
    fields: {
      status: "Approved",           ← was "approval_status"
      severity: "High",             ← was "risk_level"
      aiOnboardingStage: "Pending CISO",  ← was "onboarding_step"
      slaStatus: "On Track",        ← was "sla_state"
      approvalDays: 22              ← was "days_to_approve"
    },
    sourceId: "governance-api",
    timestamp: 2026-03-22T10:05:00Z
  }
```

---

## Stage 3: STORE (Raw) — Writing to the UseCases Collection

The writer takes `NormalizedRecord[]` and does a **partial update** on each
UseCase document. It only touches the fields this source owns.

```typescript
async function writeRecords(records: NormalizedRecord[]): Promise<WriteReport> {
  const operations: AnyBulkWriteOperation[] = [];
  const fieldsUpdated = new Set<string>();

  for (const record of records) {
    // ── Hash check: skip if nothing changed ─────────────────
    const hash = createHash('sha256')
      .update(JSON.stringify(record.fields))
      .digest('hex');

    const existing = await db.collection('useCases').findOne(
      { useCaseId: record.useCaseId },
      { projection: { [`_meta.sources.${record.sourceId}.lastHash`]: 1 } }
    );

    if (existing?._meta?.sources?.[record.sourceId]?.lastHash === hash) {
      continue; // data hasn't changed, skip the write
    }

    // ── Build the $set operation ────────────────────────────
    // Only sets THIS SOURCE'S fields — other sources' fields are untouched
    const $set: Record<string, unknown> = {
      ...record.fields,                                          // the actual data
      '_meta.updatedAt': new Date(),
      [`_meta.sources.${record.sourceId}.lastSyncedAt`]: new Date(),
      [`_meta.sources.${record.sourceId}.lastHash`]: hash,
      [`_meta.sources.${record.sourceId}.fieldsOwned`]: Object.keys(record.fields),
    };

    operations.push({
      updateOne: {
        filter: { useCaseId: record.useCaseId },
        update: {
          $set,
          $inc: { '_meta.version': 1 },
        },
        upsert: false, // don't create docs — only Identity Registry creates
      }
    });

    // Track which fields changed (for cache invalidation later)
    Object.keys(record.fields).forEach(f => fieldsUpdated.add(f));
  }

  // ── Execute batch ─────────────────────────────────────────
  let writeResult;
  if (operations.length > 0) {
    writeResult = await db.collection('useCases').bulkWrite(operations, {
      ordered: false, // continue on individual failures
    });
  }

  return {
    recordsReceived: records.length,
    recordsWritten: writeResult?.modifiedCount ?? 0,
    recordsSkippedNoOp: records.length - operations.length,
    fieldsUpdated: [...fieldsUpdated],
  };
}
```

### What the UseCase Document Looks Like Over Time

```
After Identity Registry creates it (Day 1):
┌────────────────────────────────────────────────┐
│  useCaseId: "UC-1042"                         │
│  businessCaseId: "BC-1042"                    │
│  useCaseName: "Transaction Anomaly Model"     │
│  lob: "Risk"                                  │
│  aiTechnology: "Agentic AI"                   │
│  status: null          ← not yet enriched     │
│  severity: null        ← not yet enriched     │
│  lifecycleStage: null  ← not yet enriched     │
│  driftScore: null      ← not yet enriched     │
│  monthlyCost: null     ← not yet enriched     │
│  ... (all other fields null)                  │
└────────────────────────────────────────────────┘

After Governance API enriches it (Day 1, 5 min later):
┌────────────────────────────────────────────────┐
│  useCaseId: "UC-1042"                         │
│  businessCaseId: "BC-1042"                    │
│  useCaseName: "Transaction Anomaly Model"     │
│  lob: "Risk"                                  │
│  aiTechnology: "Agentic AI"                   │
│  status: "Approved"    ← ✅ from Governance   │
│  severity: "High"      ← ✅ from Governance   │
│  slaStatus: "On Track" ← ✅ from Governance   │
│  lifecycleStage: null  ← still waiting        │
│  driftScore: null      ← still waiting        │
│  monthlyCost: null     ← still waiting        │
│  ...                                          │
└────────────────────────────────────────────────┘

After ALL sources have enriched it (Day 1, ~30 min later):
┌────────────────────────────────────────────────┐
│  useCaseId: "UC-1042"                         │
│  businessCaseId: "BC-1042"                    │
│  useCaseName: "Transaction Anomaly Model"     │
│  lob: "Risk"                                  │
│  aiTechnology: "Agentic AI"                   │
│  status: "Approved"          ← Governance     │
│  severity: "High"            ← Governance     │
│  slaStatus: "On Track"       ← Governance     │
│  lifecycleStage: "Pilot"     ← Lifecycle      │
│  daysInCurrentStage: 14      ← Lifecycle      │
│  driftScore: 0.12            ← Model Monitor  │
│  accuracy: 0.94              ← Model Monitor  │
│  criticalAlerts: 0           ← Risk Platform  │
│  responsibleAIScore: 82      ← Risk Platform  │
│  monthlyCost: 4200           ← Finance        │
│  alertType: null             ← Alert (none)   │
│  ...                                          │
└────────────────────────────────────────────────┘

This IS your AIUseCaseItem. Same shape, same fields.
It just got assembled from 6 different sources.
```

---

## Stage 4: AGGREGATE & STORE — Building Widget Data

Now you have a `useCases` collection full of enriched documents.
The generators need to turn that into widget data.

**There are two approaches here, and you need to decide which one fits:**

### Approach A: Compute on Read (Cache on Demand)

This is what the draft plan describes. Generators run MongoDB aggregation
pipelines when a widget endpoint is hit (on cache miss).

```typescript
// Generator: runs on cache miss
async function generateLifecycleKpiData(db: Db): Promise<LifecycleKpiData> {
  const pipeline = [
    { $group: {
      _id: '$lifecycleStage',
      count: { $sum: 1 }
    }},
    { $sort: { _id: 1 } }
  ];

  const results = await db.collection('useCases')
    .aggregate(pipeline)
    .toArray();

  const total = results.reduce((sum, r) => sum + r.count, 0);

  return {
    cards: results.map(r => ({
      label: r._id,
      value: r.count,
      percentage: Math.round((r.count / total) * 100),
      icon: STAGE_ICONS[r._id],
      variant: r._id === 'Production' ? 'dark' : 'light',
    }))
  };
}

// Route handler with caching
app.get('/api/widgets/:type/data', async (req, res) => {
  const { type } = req.params;
  const generator = GENERATOR_MAP[type];
  const ttl = CACHE_TIERS[type]; // 10-30s for hot, 60-120s for warm

  const data = await cache.getOrCompute(
    type,                         // cache key
    () => generator(db),          // compute function (only on miss)
    ttl                           // time-to-live
  );

  res.json({ data, meta: { timestamp: new Date().toISOString() } });
});
```

**Pros:** Simple. No extra collections. Generators are just async functions.
**Cons:** First request after cache expires has a 5-50ms latency hit.

### Approach B: Compute on Write (Pre-Aggregated Collection)

When ingestion updates a UseCase, immediately recompute affected widgets
and store the results in a `widgetData` collection. Widget endpoints just
read the pre-computed result.

```typescript
// ── widgetData collection ────────────────────────────────────
// One document per widget type:
{
  widgetType: "lifecycle-kpi",
  data: {
    cards: [
      { label: "POC", value: 48, percentage: 44, icon: "flask", variant: "light" },
      { label: "Pilot", value: 27, percentage: 25, icon: "play", variant: "light" },
      { label: "Production", value: 22, percentage: 20, icon: "rocket", variant: "dark" },
      { label: "Archived", value: 13, percentage: 12, icon: "archive", variant: "light" }
    ]
  },
  computedAt: ISODate("2026-03-22T10:05:32Z"),
  triggeredBy: { sourceId: "lifecycle-tracker", fieldsUpdated: ["lifecycleStage"] }
}

// After ingestion, recompute affected widgets:
async function onIngestionComplete(writeReport: WriteReport) {
  const affectedWidgets = resolveAffectedWidgets(writeReport.fieldsUpdated);

  for (const widgetType of affectedWidgets) {
    const generator = GENERATOR_MAP[widgetType];
    const data = await generator(db);

    await db.collection('widgetData').updateOne(
      { widgetType },
      {
        $set: {
          data,
          computedAt: new Date(),
          triggeredBy: {
            sourceId: writeReport.sourceId,
            fieldsUpdated: writeReport.fieldsUpdated,
          }
        }
      },
      { upsert: true }
    );

    // Push to Socket.io if this widget is real-time
    if (REALTIME_WIDGETS.includes(widgetType)) {
      io.to(widgetType).emit(`${widgetType}-update`, data);
    }
  }
}

// Route handler: just read the pre-computed result
app.get('/api/widgets/:type/data', async (req, res) => {
  const doc = await db.collection('widgetData').findOne({
    widgetType: req.params.type
  });
  res.json({ data: doc.data, meta: { timestamp: doc.computedAt } });
});
```

**Pros:** Widget reads are always fast (<5ms). Data is always fresh.
Socket.io push is natural — you just computed the data.
**Cons:** Extra collection. Ingestion is slightly more complex.

### Recommendation: Approach B (Compute on Write)

For your case, Approach B is cleaner because:
1. You already need the field → widget mapping for cache invalidation anyway
2. The `widgetData` collection gives you a clear "what is the client seeing right now?" audit point
3. Socket.io push falls out naturally — the data was just computed
4. Widget endpoints become trivial reads, not aggregation triggers

---

## Stage 5: SERVE — Getting Data to the Client

### Widget Endpoints

With the `widgetData` collection (Approach B), serving is a simple read:

```typescript
// ── Widget routes ────────────────────────────────────────────

app.get('/api/widgets/:type/data', async (req, res) => {
  const doc = await db.collection('widgetData').findOne({
    widgetType: req.params.type
  });

  if (!doc) {
    return res.status(404).json({ error: `Widget ${req.params.type} not computed yet` });
  }

  res.json({
    data: doc.data,
    meta: { timestamp: doc.computedAt.toISOString() }
  });
});

// Same shape as today. Same URL. Client doesn't know anything changed.
```

### Inventory Endpoint (Server-Side Pagination)

This is the one endpoint where you query the `useCases` collection directly:

```typescript
app.get('/api/inventory', async (req, res) => {
  const {
    page = '1',
    pageSize = '10',
    search,
    sortBy = 'useCaseName',
    sortOrder = 'asc',
    // Filter params — same names as current URL params
    lifecycleStage,
    slaStatus,
    status,
    severity,
    lob,
    aiTechnology,
    aiOnboardingStage,
  } = req.query;

  // ── Build filter ──────────────────────────────────────────
  const filter: Record<string, unknown> = {};
  if (lifecycleStage) filter.lifecycleStage = lifecycleStage;
  if (slaStatus) filter.slaStatus = slaStatus;
  if (status) filter.status = status;
  if (severity) filter.severity = severity;
  if (lob) filter.lob = lob;
  if (aiTechnology) filter.aiTechnology = aiTechnology;
  if (aiOnboardingStage) {
    // Partial match for comma-separated values like "Pending CISO, Pending MRM"
    filter.aiOnboardingStage = { $regex: aiOnboardingStage, $options: 'i' };
  }
  if (search) {
    filter.$text = { $search: search };
  }

  // ── Query ─────────────────────────────────────────────────
  const skip = (parseInt(page) - 1) * parseInt(pageSize);
  const sort = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

  const [data, totalItems] = await Promise.all([
    db.collection('useCases')
      .find(filter)
      .sort(sort)
      .skip(skip)
      .limit(parseInt(pageSize))
      .project({ _meta: 0 }) // don't send internal metadata to client
      .toArray(),
    db.collection('useCases').countDocuments(filter),
  ]);

  res.json({
    data,
    meta: {
      timestamp: new Date().toISOString(),
      pagination: {
        page: parseInt(page),
        pageSize: parseInt(pageSize),
        totalItems,
        totalPages: Math.ceil(totalItems / parseInt(pageSize)),
      }
    }
  });
});

// Client receives AIUseCaseItem[] in data — same shape as today.
// Only difference: it's paginated.
```

### Socket.io — Ingestion-Driven Push

```typescript
// ── In the ingestion completion handler ──────────────────────

async function onIngestionComplete(writeReport: WriteReport) {
  const affectedWidgets = resolveAffectedWidgets(writeReport.fieldsUpdated);

  for (const widgetType of affectedWidgets) {
    const generator = GENERATOR_MAP[widgetType];
    const data = await generator(db);

    // 1. Store in widgetData collection
    await db.collection('widgetData').updateOne(
      { widgetType },
      { $set: { data, computedAt: new Date() } },
      { upsert: true }
    );

    // 2. Push to any client subscribed to this widget's room
    io.to(widgetType).emit(`${widgetType}-update`, data);
  }
}

// ── Client subscribes exactly like today ─────────────────────
// In useWidgetSocket hook:
//   socket.emit('subscribe', { room: 'production-growth' });
//   socket.on('production-growth-update', (data) => setData(data));
//
// The only difference: updates come from real ingestion events
// instead of setInterval with random jitter.
```

---

## The Full Pipeline: One Complete Cycle

Let's trace what happens when the Governance API reports that UC-1042's
status changed from "Pending" to "Approved":

```
1. INGEST
   Governance API adapter polls https://governance.internal/api/cases
   Gets back: { case_ref: "BC-1042", approval_status: "Approved", ... }

2. NORMALIZE
   Resolve identity: "BC-1042" → idMappings → useCaseId: "UC-1042"
   Map fields: approval_status → status, risk_level → severity, ...
   Result: { useCaseId: "UC-1042", fields: { status: "Approved", ... } }

3. VALIDATE
   Zod checks: "Approved" is a valid ApprovalStatus ✓
   All fields match expected types ✓

4. STORE (raw)
   db.useCases.updateOne(
     { useCaseId: "UC-1042" },
     { $set: { status: "Approved", severity: "High", ... } }
   )
   Only governance-owned fields are touched.
   Lifecycle, model, risk, finance fields: untouched.

5. AGGREGATE & STORE (widget data)
   Fields updated: [status, severity, slaStatus, approvalDays]
   Affected widgets: [approval-status, approval-time, bottlenecks, onboarding-tracker]

   For each affected widget:
     Run generator against useCases collection
     Store result in widgetData collection
     Push to Socket.io room (if real-time)

6. SERVE
   Next client request to GET /api/widgets/approval-status/data
   → reads from widgetData collection
   → "Approved" count is now +1, "Pending" count is -1

   Client renders the updated donut chart. Done.
```

---

## How This Connects to Your Existing POC

```
                     POC (today)              Real Pipeline (next)
                     ──────────               ──────────────────
Data source          110-item mock array      useCases collection in MongoDB

Generators           Sync functions that      Async functions that run
                     filter/reduce the array  MongoDB aggregation pipelines

Widget endpoints     Call generator()         Read from widgetData collection
                     synchronously            (pre-computed on ingestion)

Inventory endpoint   Return full array        Query useCases with pagination

Socket.io            setInterval + jitter     Ingestion-driven push

Client               No changes               UseCasesTable → server-side
                                              pagination (only change)
```

The generators keep the same return types. The widget components keep the
same hooks. The only client-side change is UseCasesTable switching from
client-side to server-side filtering.
