# Raw Collections + Change-Driven Aggregation

## The Architecture

```
SOURCE SYSTEMS
  │
  ▼
┌──────────────────────────────────────────────────────────────┐
│  INGESTION LAYER                                             │
│  Each adapter writes to its OWN raw collection               │
│                                                              │
│  governance-api  ──▶  raw_governance    (their shape)        │
│  lifecycle-tracker──▶  raw_lifecycle    (their shape)        │
│  model-monitor  ──▶  raw_model_monitor (their shape)        │
│  risk-platform  ──▶  raw_risk          (their shape)        │
│  finance-system ──▶  raw_finance       (their shape)        │
│  alert-system   ──▶  raw_alerts        (their shape)        │
└──────────────────────────┬───────────────────────────────────┘
                           │
                    MongoDB Change Streams
                    (watch each raw collection)
                           │
                           ▼
┌──────────────────────────────────────────────────────────────┐
│  AGGREGATION LAYER                                           │
│                                                              │
│  Change event fires:                                         │
│    "raw_governance doc for BC-1042 was updated"              │
│                                                              │
│  Aggregator:                                                 │
│    1. Resolve BC-1042 → UC-1042                             │
│    2. Read ONLY the changed fields from raw_governance       │
│    3. Map to our schema                                      │
│    4. $set ONLY governance-owned fields on UC-1042           │
│    5. Recompute ONLY affected widgets                        │
│                                                              │
│  NOT: "re-read all 6 raw collections and rebuild UC-1042"   │
│  NOT: "recompute all 21 widgets"                            │
└──────────────────────────┬───────────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────┐
│  SERVING LAYER                                               │
│                                                              │
│  useCases collection     (unified, fully assembled)          │
│  widgetData collection   (pre-computed widget results)       │
│                                                              │
│  Express routes read from these                              │
│  Socket.io pushes on widget recomputation                    │
└──────────────────────────────────────────────────────────────┘
```

## Why Raw Collections?

Without raw collections, if the Governance API sends you data and you
immediately normalize + merge it into useCases, the original data is gone.

Problems that creates:
- "Why does UC-1042 show severity High?" → You can't check what Governance
  actually sent. Maybe YOUR mapping is wrong, maybe THEY sent bad data.
  Without the raw record, you're guessing.
- You change how you map `risk_level` → `severity`. Now you need to
  re-aggregate. Without raw data, you'd have to re-pull from every source.
- Governance API was down for 2 hours, then comes back with a dump of
  500 updates. You want to process them incrementally, not lose them.

With raw collections, you always have the receipts.

---

## The Raw Collections

Each source gets its own collection, storing data in THE SOURCE'S shape.
You don't normalize at this stage — you just store what they gave you.

```typescript
// ── raw_governance ───────────────────────────────────────────
// Stores exactly what the Governance API returns
{
  _id: ObjectId,
  sourceIdentifier: "BC-1042",          // their key
  data: {
    case_ref: "BC-1042",               // their field names
    approval_status: "Approved",        // their field names
    risk_level: "High",                 // their field names
    onboarding_step: "Pending CISO",
    sla_state: "On Track",
    days_to_approve: 22
  },
  receivedAt: ISODate("2026-03-22T10:05:00Z"),
  hash: "sha256:abc123...",            // for change detection
}

// ── raw_model_monitor ────────────────────────────────────────
// Stores exactly what the Model Monitor WebSocket sends
{
  _id: ObjectId,
  sourceIdentifier: "txn-anomaly-v2",   // their key (model name)
  data: {
    model_name: "txn-anomaly-v2",
    drift: 0.12,
    drift_band: "stable",
    acc: 0.94,
    p99_latency_ms: 120,
    hallucination_pct: 0.02
  },
  receivedAt: ISODate("2026-03-22T10:05:01Z"),
  hash: "sha256:def456...",
}

// ── raw_finance ──────────────────────────────────────────────
// Stores exactly what the Excel file contained
{
  _id: ObjectId,
  sourceIdentifier: "CC-FRAUD-01",      // their key (cost center)
  data: {
    "Cost Center": "CC-FRAUD-01",
    "Monthly Spend": 4200,
    "Period": "2026-03"
  },
  receivedAt: ISODate("2026-03-22T10:15:00Z"),
  hash: "sha256:ghi789...",
  fileName: "ai-costs-march-2026.xlsx", // bonus: track which file
}
```

**Index on each raw collection:** `{ sourceIdentifier: 1 }` unique.
One document per entity per source. Updates overwrite (with hash check).

---

## Smart Ingestion: Only Write What Changed

The adapter's job is now simple: pull from source, write to raw collection,
but ONLY if the data actually changed.

```typescript
async function ingestFromSource(adapter: BaseAdapter): Promise<IngestReport> {
  const rawCollection = db.collection(`raw_${adapter.sourceId}`);
  const sourceRecords = await adapter.fetch();

  const operations: AnyBulkWriteOperation[] = [];
  let skippedCount = 0;

  for (const record of sourceRecords) {
    const hash = createHash('sha256')
      .update(JSON.stringify(record.data))
      .digest('hex');

    // Only write if the hash changed — this is the "smart" part.
    // If Governance API returns 10,000 use cases but only 3 changed,
    // only 3 documents get updated, only 3 change events fire.
    operations.push({
      updateOne: {
        filter: { sourceIdentifier: record.sourceIdentifier },
        update: {
          $set: {
            data: record.data,
            receivedAt: new Date(),
            hash,
          },
          $setOnInsert: {
            sourceIdentifier: record.sourceIdentifier,
          }
        },
        // CRITICAL: only write if hash differs (or doc doesn't exist)
        // This prevents change events from firing on no-op updates
        upsert: true,
      }
    });
  }

  // bulkWrite with ordered:false — fast, continues on individual failures
  const result = await rawCollection.bulkWrite(operations, { ordered: false });

  return {
    sourceId: adapter.sourceId,
    received: sourceRecords.length,
    modified: result.modifiedCount,     // actual changes
    inserted: result.upsertedCount,     // new records
    unchanged: sourceRecords.length - result.modifiedCount - result.upsertedCount,
  };
}
```

**But wait** — `bulkWrite` with `updateOne` + `upsert` will still trigger
a change event even if you `$set` the same values. MongoDB doesn't
diff for you. The hash check needs to happen BEFORE the write:

```typescript
async function ingestFromSource(adapter: BaseAdapter): Promise<IngestReport> {
  const rawCollection = db.collection(`raw_${adapter.sourceId}`);
  const sourceRecords = await adapter.fetch();

  // Step 1: Fetch existing hashes in bulk
  const identifiers = sourceRecords.map(r => r.sourceIdentifier);
  const existingDocs = await rawCollection
    .find(
      { sourceIdentifier: { $in: identifiers } },
      { projection: { sourceIdentifier: 1, hash: 1 } }
    )
    .toArray();

  const existingHashes = new Map(
    existingDocs.map(d => [d.sourceIdentifier, d.hash])
  );

  // Step 2: Filter to only records that actually changed
  const changedRecords: typeof sourceRecords = [];
  for (const record of sourceRecords) {
    const newHash = createHash('sha256')
      .update(JSON.stringify(record.data))
      .digest('hex');

    const oldHash = existingHashes.get(record.sourceIdentifier);
    if (newHash !== oldHash) {
      changedRecords.push({ ...record, _hash: newHash });
    }
  }

  // Step 3: Write ONLY changed records
  if (changedRecords.length === 0) {
    return { sourceId: adapter.sourceId, received: sourceRecords.length,
             modified: 0, inserted: 0, unchanged: sourceRecords.length };
  }

  const operations = changedRecords.map(record => ({
    updateOne: {
      filter: { sourceIdentifier: record.sourceIdentifier },
      update: {
        $set: {
          data: record.data,
          receivedAt: new Date(),
          hash: record._hash,
        },
        $setOnInsert: { sourceIdentifier: record.sourceIdentifier },
      },
      upsert: true,
    }
  }));

  const result = await rawCollection.bulkWrite(operations, { ordered: false });

  // Now ONLY changed docs trigger change events.
  // If the source returned 10,000 records but 9,997 were identical,
  // only 3 change events fire → only 3 use cases get re-aggregated.

  return {
    sourceId: adapter.sourceId,
    received: sourceRecords.length,
    modified: result.modifiedCount,
    inserted: result.upsertedCount,
    unchanged: sourceRecords.length - changedRecords.length,
  };
}
```

---

## Change Streams: Reacting to Raw Data Changes

MongoDB Change Streams let you watch a collection for changes in real-time.
When a raw document is inserted or updated, a change event fires, and you
process ONLY that one document.

```typescript
// ── Start a change stream watcher per raw collection ─────────

function watchRawCollection(sourceId: string) {
  const rawCollection = db.collection(`raw_${sourceId}`);

  // Only care about inserts and updates (not deletes, not replaces)
  const pipeline = [
    { $match: { operationType: { $in: ['insert', 'update', 'replace'] } } }
  ];

  const changeStream = rawCollection.watch(pipeline, {
    fullDocument: 'updateLookup',  // include the full doc in the event
  });

  changeStream.on('change', async (event) => {
    const rawDoc = event.fullDocument;
    if (!rawDoc) return;

    try {
      await aggregateOne(sourceId, rawDoc);
    } catch (err) {
      // Log and continue — don't crash the watcher
      await logAggregationError(sourceId, rawDoc.sourceIdentifier, err);
    }
  });

  // Handle stream errors (connection drops, etc.)
  changeStream.on('error', (err) => {
    console.error(`Change stream error for ${sourceId}:`, err);
    // Reconnect after delay
    setTimeout(() => watchRawCollection(sourceId), 5000);
  });

  return changeStream;
}

// Start watchers for all sources
const watchers = [
  watchRawCollection('governance'),
  watchRawCollection('lifecycle'),
  watchRawCollection('model_monitor'),
  watchRawCollection('risk'),
  watchRawCollection('finance'),
  watchRawCollection('alerts'),
];
```

---

## The Aggregation Function: Process ONE Change

This is the core logic. When a single raw document changes, you:
1. Resolve its identity
2. Map its fields to your schema
3. Partially update the unified UseCase doc
4. Recompute only the affected widgets

```typescript
async function aggregateOne(sourceId: string, rawDoc: RawDocument) {
  // ── 1. Resolve identity ──────────────────────────────────
  const useCaseId = await resolveIdentity(sourceId, rawDoc.sourceIdentifier);
  if (!useCaseId) {
    await db.collection('unmappedRecords').insertOne({
      sourceId,
      sourceIdentifier: rawDoc.sourceIdentifier,
      data: rawDoc.data,
      receivedAt: new Date(),
    });
    return; // can't process without knowing who this belongs to
  }

  // ── 2. Map fields ────────────────────────────────────────
  const fieldMap = SOURCE_FIELD_MAPS[sourceId];
  const transforms = VALUE_TRANSFORMS[sourceId] ?? {};
  const mappedFields: Record<string, unknown> = {};

  for (const [sourceField, ourField] of Object.entries(fieldMap)) {
    if (rawDoc.data[sourceField] !== undefined) {
      let value = rawDoc.data[sourceField];
      if (transforms[ourField]) {
        value = transforms[ourField](value);
      }
      mappedFields[ourField] = value;
    }
  }

  // ── 3. Validate ──────────────────────────────────────────
  // Zod validates only the fields this source provides
  const partialSchema = useCaseSchema.partial().pick(
    Object.fromEntries(Object.values(fieldMap).map(f => [f, true]))
  );
  const validated = partialSchema.safeParse(mappedFields);
  if (!validated.success) {
    await logValidationError(sourceId, useCaseId, validated.error);
    return;
  }

  // ── 4. Update the unified UseCase doc ────────────────────
  // $set ONLY the fields this source owns. Nothing else is touched.
  const $set: Record<string, unknown> = {
    ...validated.data,
    '_meta.updatedAt': new Date(),
    [`_meta.sources.${sourceId}.lastSyncedAt`]: new Date(),
    [`_meta.sources.${sourceId}.fieldsOwned`]: Object.keys(validated.data),
  };

  await db.collection('useCases').updateOne(
    { useCaseId },
    { $set, $inc: { '_meta.version': 1 } }
  );

  // ── 5. Recompute ONLY affected widgets ───────────────────
  const updatedFields = Object.keys(validated.data);
  const affectedWidgets = getAffectedWidgets(updatedFields);
  await recomputeWidgets(affectedWidgets);
}
```

### The Field → Widget Mapping

```typescript
// Which widgets need recomputing when specific fields change

const FIELD_TO_WIDGETS: Record<string, string[]> = {
  lifecycleStage:      ['lifecycle-kpi', 'lifecycle-funnel', 'stage-timeline',
                        'bottlenecks', 'production-growth'],
  daysInCurrentStage:  ['stage-timeline', 'bottlenecks'],
  expectedSlaDays:     ['stage-timeline', 'bottlenecks'],
  status:              ['approval-status', 'bottlenecks'],
  severity:            ['approval-status'],
  slaStatus:           ['approval-time', 'bottlenecks', 'onboarding-tracker'],
  approvalDays:        ['approval-time'],
  aiOnboardingStage:   ['onboarding-tracker'],
  driftScore:          ['behavioral-drift', 'risk-score-breakdown'],
  accuracy:            ['model-performance'],
  latency:             ['model-performance'],
  hallucinationRate:   ['model-quality-risk'],
  criticalAlerts:      ['live-risk-events', 'risk-score-breakdown'],
  policyViolations:    ['live-risk-events', 'risk-score-breakdown'],
  guardrailTriggers:   ['live-risk-events', 'risk-score-breakdown'],
  responsibleAIScore:  ['responsible-ai-index', 'ai-index-trend'],
  monthlyCost:         ['monthly-cost'],
  lob:                 ['use-cases-by-bu', 'lifecycle-kpi'],
  aiTechnology:        ['tech-distribution'],
  alertType:           ['attention-queue'],
  alertStatus:         ['attention-queue'],
  isActive:            ['risk-stats', 'live-risk-events'],
  agentName:           ['risk-stats', 'behavioral-drift', 'risk-score-breakdown'],
};

function getAffectedWidgets(updatedFields: string[]): string[] {
  const widgets = new Set<string>();
  for (const field of updatedFields) {
    const affected = FIELD_TO_WIDGETS[field];
    if (affected) {
      affected.forEach(w => widgets.add(w));
    }
  }
  return [...widgets];
}
```

### Recompute Widgets (Targeted, Not All 21)

```typescript
async function recomputeWidgets(widgetTypes: string[]) {
  for (const widgetType of widgetTypes) {
    const generator = GENERATOR_MAP[widgetType];
    const data = await generator(db);

    // Store pre-computed result
    await db.collection('widgetData').updateOne(
      { widgetType },
      {
        $set: {
          data,
          computedAt: new Date(),
        }
      },
      { upsert: true }
    );

    // Push to subscribed clients via Socket.io
    io.to(widgetType).emit(`${widgetType}-update`, data);
  }
}
```

---

## Concrete Example: What Happens When Governance API Returns 10,000 Records

```
Timeline:

T+0s   Governance adapter polls the API
       Response: 10,000 records (every use case they know about)

T+1s   Hash comparison against raw_governance collection
       9,994 records have identical hash → SKIP
       6 records have changed hashes → WRITE

T+2s   bulkWrite to raw_governance: 6 updateOne operations
       6 change events fire on the raw_governance change stream
       9,994 records caused ZERO database writes, ZERO events

T+2s   Change stream handler picks up event #1:
       "raw_governance doc for BC-1042 was updated"
       → Resolve BC-1042 → UC-1042
       → Map fields: approval_status→status, risk_level→severity, ...
       → $set on useCases: ONLY governance fields for UC-1042
       → Affected widgets: [approval-status, approval-time, bottlenecks]
       → Recompute those 3 widgets (not all 21)
       → Push to Socket.io rooms

T+2s   Events #2-#6 processed similarly (likely in parallel)
       Each updates ONLY the use case that changed
       Each recomputes ONLY the widgets affected by governance fields

T+3s   Done. Total work:
       - 6 raw_governance writes (not 10,000)
       - 6 useCases partial updates (not 10,000)
       - 3 unique widgets recomputed (not 21)
       - 3 Socket.io pushes (only to rooms with subscribers)
```

---

## Another Example: Excel File Drop (Full Re-Send Problem)

Finance drops a new Excel file every month with ALL cost data.
The file has 10,000 rows, but only 50 costs actually changed.

```
T+0s   File watcher detects new file: ai-costs-march-2026.xlsx
       Excel adapter reads all 10,000 rows

T+1s   Hash comparison against raw_finance:
       9,950 rows → same hash → SKIP
       50 rows → different hash → WRITE

T+2s   bulkWrite to raw_finance: 50 writes
       50 change events fire
       9,950 rows caused zero work

T+3s   Each change event:
       → Resolve cost center → useCaseId (via idMappings)
       → Map "Monthly Spend" → monthlyCost
       → $set monthlyCost on the specific use case
       → Recompute: [monthly-cost] (just 1 widget)
       → But wait — monthly-cost aggregates ALL use cases...

       Smart optimization: BATCH the widget recomputation.
       Don't recompute monthly-cost 50 times.
       Collect all 50 change events, then recompute once.
```

### Batching Widget Recomputation (Debounce)

When multiple change events fire in quick succession (common during
batch ingestion), you don't want to recompute the same widget 50 times.

```typescript
class WidgetRecomputeQueue {
  private pending = new Map<string, NodeJS.Timeout>();
  private debounceMs: number;

  constructor(debounceMs = 500) {
    this.debounceMs = debounceMs;
  }

  enqueue(widgetTypes: string[]) {
    for (const widgetType of widgetTypes) {
      // If this widget is already queued, reset its timer
      if (this.pending.has(widgetType)) {
        clearTimeout(this.pending.get(widgetType)!);
      }

      // Schedule recomputation after debounce window
      this.pending.set(widgetType, setTimeout(async () => {
        this.pending.delete(widgetType);
        await this.recompute(widgetType);
      }, this.debounceMs));
    }
  }

  private async recompute(widgetType: string) {
    const generator = GENERATOR_MAP[widgetType];
    const data = await generator(db);

    await db.collection('widgetData').updateOne(
      { widgetType },
      { $set: { data, computedAt: new Date() } },
      { upsert: true }
    );

    io.to(widgetType).emit(`${widgetType}-update`, data);
  }
}

const recomputeQueue = new WidgetRecomputeQueue(500); // 500ms debounce

// In the change stream handler:
async function aggregateOne(sourceId: string, rawDoc: RawDocument) {
  // ... resolve identity, map fields, update useCases ...

  const updatedFields = Object.keys(validated.data);
  const affectedWidgets = getAffectedWidgets(updatedFields);

  // Don't recompute immediately — enqueue with debounce
  recomputeQueue.enqueue(affectedWidgets);
}
```

Now when Finance drops 50 changed records:
- 50 change events fire
- 50 useCases get their `monthlyCost` updated (one at a time, fast)
- `monthly-cost` widget gets enqueued 50 times, but only recomputed ONCE
  (after the last event + 500ms debounce)

---

## The Full Collection Layout

```
MongoDB Collections:

── Raw (per source, stores their data in their shape) ──────────

  raw_governance        { sourceIdentifier, data: {...}, hash, receivedAt }
  raw_lifecycle         { sourceIdentifier, data: {...}, hash, receivedAt }
  raw_model_monitor     { sourceIdentifier, data: {...}, hash, receivedAt }
  raw_risk              { sourceIdentifier, data: {...}, hash, receivedAt }
  raw_finance           { sourceIdentifier, data: {...}, hash, receivedAt }
  raw_alerts            { sourceIdentifier, data: {...}, hash, receivedAt }

── Identity Resolution ─────────────────────────────────────────

  idMappings            { useCaseId, mappings: { sourceId: nativeId, ... } }

── Unified (assembled from all raw sources) ────────────────────

  businessCases         { businessCaseId, title, owner, lob, ... }
  useCases              { useCaseId, businessCaseId, ...all fields, _meta }

── Pre-Computed for Serving ────────────────────────────────────

  widgetData            { widgetType, data: {...}, computedAt }

── Operational ─────────────────────────────────────────────────

  ingestionLogs         { sourceId, runId, stats, errors, ... }  TTL: 90d
  unmappedRecords       { sourceId, sourceIdentifier, data, ... }  TTL: 30d
  sourceConfigs         { sourceId, type, schedule, fieldMap, ... }
```

---

## Request Flow Summary

### Widget Request (e.g. lifecycle-kpi)

```
Client: GET /api/widgets/lifecycle-kpi/data
  │
  ▼
Server: db.widgetData.findOne({ widgetType: 'lifecycle-kpi' })
  │
  ▼
Return pre-computed data. Done. (~2ms)
```

No aggregation pipeline runs. No cache miss. The data was pre-computed
when the last relevant ingestion event fired.

### Inventory Request (table with filters)

```
Client: GET /api/inventory?lifecycleStage=POC&page=1&pageSize=10
  │
  ▼
Server: db.useCases.find({ lifecycleStage: 'POC' })
          .sort({ useCaseName: 1 })
          .skip(0).limit(10)
          .project({ _meta: 0 })
  │
  ▼
Return paginated UseCase docs. Done. (~5-15ms with index)
```

This reads from the unified useCases collection directly — no
aggregation needed, just a filtered query.

### Real-Time Widget (e.g. production-growth via Socket.io)

```
Client subscribes: socket.emit('subscribe', { room: 'production-growth' })

  ... time passes ...

Lifecycle tracker reports UC-1042 moved to Production
  │
  ▼
Change stream on raw_lifecycle fires
  │
  ▼
aggregateOne: updates UC-1042 in useCases
  │
  ▼
recomputeQueue.enqueue(['production-growth', 'lifecycle-kpi', ...])
  │
  ▼ (after debounce)
  │
Recompute production-growth, store in widgetData
  │
  ▼
io.to('production-growth').emit('production-growth-update', newData)
  │
  ▼
Client receives push, React re-renders. No polling.
```
