# Command Center — High-Level Design: Real Data Pipeline

**Status:** Draft for Review  
**Author:** Architecture Team  
**Last Updated:** March 2026

---

## 1. Executive Summary

Command Center is a dashboard that aggregates data from 7+ disparate source systems into a single unified view of every AI initiative across the organization. It provides KPI widgets, interactive charts, a filterable inventory table, and drill-down detail panels — giving stakeholders the first comprehensive picture of business case and use case status, governance approvals, model health, risk posture, and cost.

A working proof-of-concept exists today as a TurboRepo monorepo (React + Vite client, Express + Socket.io server). The POC runs on 110 hardcoded mock `AIUseCaseItem` objects. All 21 widget generators derive from this in-memory array. The server-driven dashboard config, lazy-loaded widgets, URL-driven table filtering, widget-to-table drill-down, and slide-out detail panel are all complete and functional.

This HLD covers the next phase: replacing the mock data layer with a real ingestion pipeline. It defines the entity model, source identity resolution strategy, end-to-end data flow, ingestion architecture, database recommendation, serving/caching approach, API changes, client impact, and migration plan. The design goal is to preserve the entire existing frontend contract while moving the data source from a static array to a live, multi-source aggregated store.

---

## 2. Entity Model: Business Case vs. Use Case

### The Distinction

In the organization's real-world process, a **business case** is the top-level entity that moves through the approval lifecycle. A business case may contain one or more **use cases** — each representing a distinct AI application or model deployment. For example, business case `BC-1042` ("Fraud Detection AI Program") might contain use case `UC-1042-A` ("Transaction Anomaly Model") and `UC-1042-B` ("Identity Verification Agent").

### V1 Decision: Use Case as the Atomic Unit

For V1, the **use case remains the primary entity**. Rationale:

- The entire POC — all 21 generators, the inventory table, the detail panel, the widget-to-table drill-down — is built around `AIUseCaseItem`. Changing the atomic unit would invalidate the entire working frontend.
- The majority of source systems report at the use case level (model metrics, drift scores, alerts). Only the Identity Registry and possibly the Governance API naturally operate at the business case level.
- Most dashboard questions are use-case-scoped: "How many use cases are in Production?", "Which use case is breaching SLA?", "What's the drift score for this model?"

The `businessCaseId` field already exists on every `AIUseCaseItem`. This is the foreign key that enables future hierarchy.

### Data Model Implication

```
useCases collection (V1):
┌──────────────────────────────────────┐
│  useCaseId:      "UC-1042-A"  (PK)  │
│  businessCaseId: "BC-1042"    (FK)  │
│  useCaseName:    "Transaction..."    │
│  ... all other fields ...            │
│  _meta: { ... }                      │
└──────────────────────────────────────┘
```

### Path to Business Case Hierarchy (V2)

If a parent entity is needed later (e.g., a "Business Case Overview" page), the upgrade path is:

1. Add a `businessCases` collection with fields like `businessCaseId`, `title`, `owner`, `submissionDate`, `overallStatus`
2. The existing `businessCaseId` on every use case document becomes the join key
3. Add an aggregation endpoint that groups use cases by `businessCaseId` and rolls up status
4. No existing widget, table, or generator breaks — they continue operating on use case documents

This is a low-risk additive change, not a migration.

---

## 3. Source Systems & Cross-Source Identity Resolution

### Source Inventory

| # | Source | Type | Fields Owned | Refresh | Creates New Records? |
|---|--------|------|-------------|---------|---------------------|
| 1 | **Identity Registry** | REST poll | `businessCaseId`, `useCaseId`, `useCaseName`, `lob`, `aiTechnology` | 5 min | **Yes** — authoritative source for new use cases |
| 2 | **Governance API** | REST poll | `status`, `severity`, `aiOnboardingStage`, `slaStatus`, `approvalDays` | 5 min | No |
| 3 | **Lifecycle Tracker** | REST poll | `lifecycleStage`, `daysInCurrentStage`, `expectedSlaDays` | 5 min | No |
| 4 | **Model Monitor** | WebSocket | `driftScore`, `driftCategory`, `accuracy`, `latency`, `hallucinationRate` | Real-time | No |
| 5 | **Risk Platform** | REST poll | `criticalAlerts`, `policyViolations`, `guardrailTriggers`, `responsibleAIScore` | 1–5 min | No |
| 6 | **Finance System** | Excel file drop | `monthlyCost` | On file drop / 15 min scan | No |
| 7 | **Alert System** | Email/REST | `alertType`, `alertStatus`, `owner`, `detectedTime` | 10 min | No |

### The Identity Problem

The draft plan assumes all sources use `useCaseId` as the join key. This is unrealistic. In practice:

- The **Identity Registry** may use its own internal ID alongside `useCaseId`
- The **Governance API** likely keys on `businessCaseId` and may not carry `useCaseId` at all
- The **Finance System** (Excel) may reference a project code or cost center, not a use case ID
- The **Alert System** may use a model name or deployment identifier

### Resolution Strategy: Canonical ID Mapping Table

The ingestion layer maintains a **mapping registry** — a persistent lookup that resolves each source's native identifier to the canonical `useCaseId`.

```
┌─────────────────────────────────────────────────────┐
│  idMappings collection                              │
│                                                     │
│  { useCaseId: "UC-1042",                           │
│    mappings: {                                      │
│      "src-identity":   "IR-7821",                  │
│      "src-governance":  "BC-1042",    ← by BCID    │
│      "src-finance":     "CC-FRAUD-01", ← cost ctr  │
│      "src-alerts":      "txn-anomaly-prod" ← model │
│    }                                                │
│  }                                                  │
└─────────────────────────────────────────────────────┘
```

**How it works:**

1. The Identity Registry adapter creates both the `useCases` document and the initial `idMappings` entry during onboarding
2. Each other adapter's normalizer looks up its source-native ID in `idMappings` to resolve the canonical `useCaseId`
3. If a record cannot be resolved, it is written to a **dead letter queue** (`unmappedRecords` collection) with the source ID and timestamp for manual resolution
4. Mappings can be seeded from a spreadsheet or populated incrementally as sources are onboarded

**Why not enforce a single ID across all sources?** Because we don't control the source systems. They predate Command Center. Enforcing a universal key would require changes to 7 upstream systems — a political and technical non-starter.

### Field Ownership & Conflict Policy

The draft claims "no two sources own the same field — conflicts prevented by design." This is the **goal** but unlikely to hold perfectly. Realistic conflict scenarios:

- The Governance API and the Lifecycle Tracker might both report something resembling lifecycle status
- The Risk Platform and the Alert System could both report alert counts

**Policy:**

1. **Primary ownership is defined in source config** — each adapter declares which fields it is authorized to write
2. **If two sources attempt to write the same field**, the ingestion writer logs a conflict event and applies the **most-recently-timestamped** value, recording both in the audit log
3. **Field ownership disputes are surfaced** in the admin dashboard, not silently resolved — this is a data governance question, not a code question
4. **The `_meta.sources` object on each document** tracks which source last wrote each field, enabling forensic investigation

---

## 4. Data Flow: End-to-End Pipeline

### Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│  SOURCE SYSTEMS                                                  │
│  Identity Registry | Governance API | Lifecycle Tracker |        │
│  Model Monitor | Risk Platform | Finance (Excel) | Alerts       │
└───────┬──────────────────────────────────────────────────────────┘
        │
        ▼
┌──────────────────────────────────────────────────────────────────┐
│  INGESTION LAYER                                                 │
│                                                                  │
│  ┌───────────┐   ┌────────────┐   ┌───────────┐   ┌──────────┐ │
│  │  Adapter   │──▶│ Normalizer │──▶│ Validator │──▶│  Writer  │ │
│  │ (per src)  │   │ (resolve   │   │ (Zod      │   │ (batched │ │
│  │            │   │  IDs, map  │   │  schema)  │   │  upsert) │ │
│  │            │   │  fields)   │   │           │   │          │ │
│  └───────────┘   └────────────┘   └───────────┘   └────┬─────┘ │
│                                                         │       │
│  ┌─────────────────┐   ┌──────────────────────────┐     │       │
│  │ Dead Letter Q    │   │ Ingestion Audit Log      │◀────┘       │
│  │ (unresolved IDs) │   │ (per-run stats + errors) │             │
│  └─────────────────┘   └──────────────────────────┘             │
└─────────────────────────────────┬────────────────────────────────┘
                                  │  writes
                                  ▼
┌──────────────────────────────────────────────────────────────────┐
│  DATABASE (MongoDB recommended)                                  │
│                                                                  │
│  useCases        ← one doc per use case, flat fields + _meta    │
│  idMappings      ← cross-source identity resolution             │
│  ingestionLogs   ← audit trail, TTL 90 days                     │
│  unmappedRecords ← dead letter queue                            │
│  sourceConfigs   ← adapter configuration                        │
└─────────────────────────────────┬────────────────────────────────┘
                                  │  reads
                                  ▼
┌──────────────────────────────────────────────────────────────────┐
│  SERVING LAYER                                                   │
│                                                                  │
│  ┌─────────────────────┐                                        │
│  │ Widget Cache (LRU)  │  ← field-to-widget invalidation       │
│  │    hit: 0ms         │                                        │
│  │    miss ──▶ Generator (async MongoDB aggregation)            │
│  │              5-50ms at 50K docs                              │
│  └──────────┬──────────┘                                        │
│             │                                                    │
│  ┌──────────▼──────────┐   ┌──────────────────────┐            │
│  │ Express Routes      │   │ Socket.io            │            │
│  │ (unchanged URLs)    │   │ (ingestion-driven    │            │
│  │                     │   │  push on invalidation)│            │
│  └──────────┬──────────┘   └──────────┬───────────┘            │
└─────────────┼─────────────────────────┼──────────────────────────┘
              │                         │
              ▼                         ▼
┌──────────────────────────────────────────────────────────────────┐
│  REACT CLIENT (unchanged)                                        │
│  Same hooks, same widget components, same table                  │
│  Only change: UseCasesTable → server-side pagination             │
└──────────────────────────────────────────────────────────────────┘
```

### Numbered Flow

1. **Source emits data** — an API responds to a poll, a WebSocket pushes a message, a new Excel file lands, or an email arrives
2. **Adapter extracts raw records** — the per-source adapter handles protocol concerns (HTTP, WS, file I/O, IMAP) and emits raw source-shaped records
3. **Normalizer resolves identity and maps fields** — looks up the source's native ID in `idMappings` to get `useCaseId`, then maps source-specific field names to `AIUseCaseItem` field names. Output: `NormalizedRecord[]`
4. **Validator checks schema** — each `NormalizedRecord` is validated against a Zod schema derived from the `AIUseCaseItem` TypeScript type. Invalid records are logged and skipped; the batch continues
5. **Writer performs batched upsert** — a `bulkWrite` with `updateOne` + `$set` per record. Only the source's owned fields and `_meta.sources.<sourceId>` are touched. Hash comparison skips no-op writes. The `_meta.version` field provides optimistic concurrency
6. **Writer logs the ingestion run** — a document in `ingestionLogs` records: source ID, timestamp, records processed, records skipped, errors encountered
7. **Writer triggers cache invalidation** — based on which fields were updated, the corresponding widget caches are evicted (using the field → widget mapping)
8. **Next widget request hits the serving layer** — cache miss triggers the generator, which runs a MongoDB aggregation pipeline and caches the result
9. **Socket.io pushes to subscribed clients** — if a real-time widget's cache was invalidated, the recomputed data is pushed to the Socket.io room
10. **Client renders** — widget hooks receive new data via REST response or Socket.io event; no component changes needed

### Concrete Example: `lifecycleStage` Changes from "POC" to "Pilot"

1. The **Lifecycle Tracker** REST API returns an updated record for `UC-1042` with `stage: "Pilot"`
2. The `lifecycle-tracker` adapter polls the API and extracts the raw record
3. The normalizer maps `stage` → `lifecycleStage`, resolves the source's ID to `useCaseId: "UC-1042"`
4. The validator confirms `"Pilot"` is a valid `LifecycleStage` enum value
5. The writer issues: `db.useCases.updateOne({ useCaseId: "UC-1042" }, { $set: { lifecycleStage: "Pilot", "_meta.sources.src-lifecycle.lastSyncedAt": now, "_meta.updatedAt": now }, $inc: { "_meta.version": 1 } })`
6. The writer checks the field → widget map: `lifecycleStage` invalidates `lifecycle-kpi`, `lifecycle-funnel`, `stage-timeline`, `bottlenecks`, `production-growth`
7. Those 5 cache entries are evicted
8. The next `GET /api/widgets/lifecycle-kpi/data` triggers a cache miss → the generator runs `$group` by `lifecycleStage` against MongoDB → "Pilot" count is now +1, "POC" count is −1
9. If `production-growth` is subscribed via Socket.io, the recomputed data is pushed immediately

---

## 5. Ingestion Layer Architecture

### Adapter Contract

Every adapter implements a common interface:

```
┌────────────────────────────────────────────┐
│  BaseAdapter                               │
│                                            │
│  id:          string (e.g. "src-lifecycle") │
│  sourceType:  "rest" | "ws" | "file" | ... │
│  fieldsOwned: string[]                     │
│                                            │
│  start():     begin polling/listening       │
│  stop():      graceful shutdown             │
│  fetch():     NormalizedRecord[]            │
│  healthCheck(): AdapterHealth              │
│                                            │
│  Config loaded from sourceConfigs collection│
└────────────────────────────────────────────┘
```

### Adapter Types

| Adapter Type | Protocol | Lifecycle | Error Recovery |
|-------------|----------|-----------|----------------|
| **REST Poller** | HTTP GET on cron (1–5 min) | Start cron → stop clears timer | Retry with exponential backoff (3 attempts per cycle), then skip cycle and log |
| **WebSocket Listener** | Persistent WS connection | Connect on start, reconnect on drop | Exponential backoff reconnect (1s → 2s → 4s → ... → 60s cap). Buffer missed messages if source supports replay |
| **File Watcher** | Filesystem watch + fallback cron | Watch directory, process new files | Parse errors → log failed file, move to `failed/` directory, alert. Retry on next file drop |
| **Email Parser** | IMAP poll or filesystem watch on `.eml` | Poll on cron (10 min) | Parse errors → skip message, log. Mark processed messages to avoid reprocessing |

### Adapter Registry

The registry manages the lifecycle of all adapters:

- **Discovery:** Reads `sourceConfigs` collection on startup, instantiates one adapter per active config
- **Health monitoring:** Periodic health checks; tracks consecutive failure count per adapter
- **Circuit breaker:** After 5 consecutive failures, the adapter is disabled and an alert is raised. Manual re-enable via admin endpoint
- **Graceful shutdown:** On `SIGTERM`, calls `stop()` on all adapters before process exit

### Normalizer

The normalizer sits between the adapter and the writer. For each raw record it:

1. **Resolves identity** — looks up the source-native ID in `idMappings` to get `useCaseId`. If unresolvable, routes to the dead letter queue
2. **Maps fields** — transforms source field names to `AIUseCaseItem` field names per the source config's field mapping
3. **Stamps metadata** — attaches `sourceId` and `timestamp`

Output: `NormalizedRecord { useCaseId, fields: Partial<AIUseCaseItem>, sourceId, timestamp }`

### Writer (Batched Upsert with Deduplication)

The writer receives `NormalizedRecord[]` and:

1. **Computes hash** per record (hash of `JSON.stringify(fields)`)
2. **Compares against `_meta.sources.<sourceId>.lastHash`** — if identical, skips the write (critical for Excel/email sources that re-send full datasets)
3. **Builds a `bulkWrite` batch** of `updateOne` operations with `$set` limited to the source's owned fields
4. **Executes the batch** with ordered: false (continues on individual failures)
5. **Returns a write report** — records written, records skipped (no-op), records failed, fields updated
6. **Triggers cache invalidation** — maps updated fields to affected widgets and evicts their cache entries

### Error Handling Strategy

The draft's "retry 3x" is a starting point but insufficient. Here is the full strategy:

| Failure Mode | Response | Escalation |
|-------------|----------|------------|
| **Source unreachable** (network, 5xx) | Retry 3x with exponential backoff within the cycle. On exhaustion, skip this cycle, log warning | After 3 consecutive failed cycles (not retries — full cycles), raise alert to admin dashboard. After 5, circuit-break the adapter |
| **Source returns bad data** (schema violation) | Log the specific record(s) that failed validation, skip them, continue the batch. Healthy records are still written | If >50% of a batch fails validation, flag the entire ingestion run as degraded in the audit log |
| **Identity resolution failure** | Route record to `unmappedRecords` (dead letter queue) with source ID and raw payload | Surface in admin dashboard for manual mapping |
| **Database write failure** | Retry the batch once. On second failure, log entire batch to `ingestionLogs` as failed with full payload for replay | Alert. The batch can be replayed from the audit log via admin endpoint |
| **Source down for extended period** | Adapter continues attempting on schedule. Data in the database is stale but valid — the `_meta.sources.<sourceId>.lastSyncedAt` timestamp shows the age | Admin dashboard shows "last sync" per source. Staleness beyond a configurable threshold triggers a visual warning |

### Audit Logging

Every ingestion run produces an `ingestionLogs` document:

```
{
  sourceId: "src-lifecycle",
  runId: "run-2026-03-22T10:05:00Z",
  startedAt: ISODate,
  completedAt: ISODate,
  status: "completed" | "partial" | "failed",
  stats: {
    recordsReceived: 1200,
    recordsWritten: 1195,
    recordsSkippedNoOp: 3,
    recordsSkippedInvalid: 2,
    recordsFailed: 0
  },
  errors: [ { useCaseId: "UC-9999", error: "Invalid lifecycleStage: 'Unknown'" } ],
  fieldsUpdated: ["lifecycleStage", "daysInCurrentStage"],
  widgetsInvalidated: ["lifecycle-kpi", "lifecycle-funnel", "stage-timeline"]
}
```

TTL: 90 days. Retained for debugging and compliance.

---

## 6. Database Design — Recommendation with Trade-Offs

### Requirements

The database must satisfy:

1. **Schema flexibility** — the unified entity schema is still being defined and will evolve as sources are onboarded. Schema changes must not require downtime or complex migrations
2. **Partial updates from multiple sources** — each source writes only its owned fields without touching the rest of the document
3. **Aggregation queries matching our 21 generators** — count, average, group-by, filter, match patterns. Not complex analytics (no window functions, CTEs, or star-schema joins)
4. **Scale to tens of thousands now** with a clear path to hundreds of thousands. Not millions in the foreseeable future
5. **Single entity type** — no joins, no fact/dimension tables. One collection/table is the primary read target
6. **Metadata tracking** — per-source sync timestamps, field ownership, hash-based deduplication stored alongside the data

### Option A: MongoDB (Recommended)

**Strengths:**

- **Schema evolution is a non-event.** Add or remove fields by changing the Zod schema and the TypeScript type. No migrations, no `ALTER TABLE`, no rollback plans. During the integration phase where the schema changes weekly, this eliminates an entire class of risk
- **Partial `$set` updates are first-class.** Each adapter writes only its owned fields: `$set: { lifecycleStage: "Pilot", "_meta.sources.src-lifecycle.lastSyncedAt": now }`. Other fields are untouched without explicit NULL handling
- **`_meta` as a nested object is natural.** The per-source tracking metadata fits cleanly inside the document without extra tables or JSON columns
- **Aggregation pipeline covers all 21 generators.** Every current in-memory operation (filter, count, group, average) has a direct pipeline equivalent. At 50K documents with proper indexes, all pipelines complete in under 50ms
- **Operational simplicity.** Single dependency. Connection pooling via the native driver. No ORM needed at this complexity level

**Risks:**

- No native materialized views — if generators become expensive, pre-aggregation must be done at the application level (the cache layer handles this for V1)
- Full-text search is adequate for the current use case (`$text` index) but would need Elasticsearch if fuzzy matching or relevance scoring is required later
- No referential integrity enforcement — the application layer must ensure an adapter doesn't write to a non-existent `useCaseId`

### Option B: PostgreSQL

**Strengths:**

- Stronger full-text search via `tsvector`
- Native `MATERIALIZED VIEW` for pre-aggregation
- Referential integrity via foreign keys (useful if `businessCases` table is added later)
- Better tooling ecosystem for analytics if requirements expand toward OLAP

**Risks:**

- **Schema change friction is the #1 concern.** Every field addition or removal requires an `ALTER TABLE` + migration file + testing. During the integration phase, this is a significant drag on velocity
- Wide table with 30+ columns, many nullable, is awkward. Normalizing into multiple tables adds join complexity for a use case that doesn't benefit from normalization
- Partial updates require explicit `SET field = COALESCE(new_value, field)` patterns or column-level conflict resolution, which is more complex than MongoDB's `$set`
- JSONB columns are an alternative for flexible fields, but then you lose the SQL advantages (typed queries, indexes on individual fields) for those fields

### Recommendation

**Start with MongoDB.** The primary risk during this phase is schema instability, and MongoDB eliminates that risk entirely. All 21 generators translate directly to aggregation pipelines. The in-process LRU cache handles the pre-aggregation concern. Scale to hundreds of thousands is well within MongoDB's comfort zone.

**Revisit this decision if:**

- The schema stabilizes AND analytics requirements expand beyond simple aggregations (window functions, complex joins, OLAP patterns)
- A `businessCases` parent entity with enforced referential integrity becomes a hard requirement
- Full-text search needs exceed what MongoDB `$text` + application-level filtering can deliver

### Collection Design

| Collection | Purpose | TTL |
|-----------|---------|-----|
| `useCases` | One document per use case. All `AIUseCaseItem` fields flat at top level + `_meta` for source tracking | None |
| `idMappings` | Cross-source identity resolution. One document per `useCaseId` with a map of source-native IDs | None |
| `ingestionLogs` | Audit trail per ingestion run | 90 days |
| `unmappedRecords` | Dead letter queue for records that couldn't be resolved to a `useCaseId` | 30 days |
| `sourceConfigs` | Configuration per adapter (type, schedule, field mappings, endpoint URL) | None |

### Document Schema (`useCases`)

```json
{
  "_id": "ObjectId",
  "useCaseId": "UC-1042",
  "businessCaseId": "BC-1042",

  "useCaseName": "Transaction Anomaly Model",
  "lob": "Risk",
  "lifecycleStage": "Pilot",
  "aiOnboardingStage": "Pending CISO",
  "slaStatus": "On Track",
  "aiTechnology": "Agentic AI",
  "status": "Approved",
  "severity": "High",

  "daysInCurrentStage": 14,
  "expectedSlaDays": 30,
  "approvalDays": 22,
  "isActive": true,
  "agentName": "txn-anomaly-v2",
  "driftScore": 0.12,
  "driftCategory": "Stable",
  "criticalAlerts": 0,
  "policyViolations": 1,
  "guardrailTriggers": 3,
  "monthlyCost": 4200,
  "responsibleAIScore": 82,
  "accuracy": 0.94,
  "latency": 120,
  "hallucinationRate": 0.02,

  "alertType": null,
  "alertStatus": null,
  "owner": null,
  "detectedTime": null,

  "_meta": {
    "createdAt": "ISODate",
    "updatedAt": "ISODate",
    "version": 5,
    "sources": {
      "src-identity": {
        "lastSyncedAt": "ISODate",
        "fieldsOwned": ["businessCaseId", "useCaseId", "useCaseName", "lob", "aiTechnology"],
        "lastHash": "sha256:abc..."
      },
      "src-governance": {
        "lastSyncedAt": "ISODate",
        "fieldsOwned": ["status", "severity", "aiOnboardingStage", "slaStatus", "approvalDays"],
        "lastHash": "sha256:def..."
      }
    }
  }
}
```

### Index Strategy

| Index | Fields | Purpose |
|-------|--------|---------|
| Unique key | `{ useCaseId: 1 }` unique | All ingestion upserts, all lookups |
| Lifecycle stage | `{ lifecycleStage: 1 }` | 6 generators + table filter |
| Active items | `{ isActive: 1 }` | 5 generators (risk/compliance widgets) |
| Agent items | `{ agentName: 1 }` partial (non-null) | 5 generators (model metrics widgets) |
| Table filters | `{ lob: 1, slaStatus: 1, status: 1, severity: 1 }` compound | Inventory table filtering |
| Text search | `{ useCaseName: "text", useCaseId: "text", businessCaseId: "text" }` | Table search |

At 50K documents, all indexes fit in RAM (under 50MB). The entire working set is under 500MB.

### Generator → Aggregation Pipeline Mapping

| Generator Pattern | MongoDB Equivalent |
|------------------|-------------------|
| `items.filter(i => i.lifecycleStage === 'POC').length` | `$match` + `$count` |
| `items.reduce((sum, i) => sum + i.approvalDays, 0) / items.length` | `$group` + `$avg` |
| `items.filter(i => i.alertType !== null)` | `$match: { alertType: { $ne: null } }` |
| Group by field, count per group | `$group: { _id: '$field', count: { $sum: 1 } }` |
| Filter active + compute averages | `$match: { isActive: true }` → `$group` with `$avg` |

---

## 7. Serving Layer & Caching

### Widget Endpoint Flow

```
Client request: GET /api/widgets/lifecycle-kpi/data
         │
         ▼
    ┌─────────┐     hit      ┌──────────┐
    │  Route   │────────────▶│  Return   │
    │ Handler  │             │  cached   │
    └────┬────┘             └──────────┘
         │ miss
         ▼
    ┌─────────────┐
    │  Generator   │  (async MongoDB aggregation pipeline)
    │  5-50ms      │
    └──────┬──────┘
           │
           ▼
    ┌─────────────┐
    │  Cache result│  (with tier-appropriate TTL)
    │  + return    │
    └─────────────┘
```

Route handlers change from synchronous `generator()` calls to `await cache.getOrCompute(type, () => generator(db), ttl)`. Return types are identical — the frontend contract is unchanged.

### Cache Tiers

| Tier | TTL | Widgets | Rationale |
|------|-----|---------|-----------|
| **Hot** | 10–30s | `lifecycle-kpi`, `risk-stats`, `live-risk-events`, `production-growth`, `monthly-cost` | High-traffic, change frequently with ingestion |
| **Warm** | 60–120s | All other 16 widgets | Analytical/trend data; slight staleness is acceptable |

### Cache Invalidation: Field → Widget Mapping

When the ingestion writer updates specific fields, it evicts the cache entries for the affected widgets:

| Fields Updated | Widgets Invalidated |
|---------------|-------------------|
| `lifecycleStage`, `daysInCurrentStage`, `expectedSlaDays` | `lifecycle-kpi`, `lifecycle-funnel`, `stage-timeline`, `bottlenecks`, `production-growth` |
| `status`, `severity`, `slaStatus`, `approvalDays` | `approval-status`, `approval-time`, `bottlenecks`, `onboarding-tracker` |
| `driftScore`, `accuracy`, `latency`, `hallucinationRate` | `model-performance`, `model-quality-risk`, `behavioral-drift`, `risk-score-breakdown` |
| `criticalAlerts`, `policyViolations`, `guardrailTriggers`, `responsibleAIScore` | `live-risk-events`, `responsible-ai-index`, `ai-index-trend`, `risk-score-breakdown` |
| `monthlyCost` | `monthly-cost` |
| `lob`, `aiTechnology` | `use-cases-by-bu`, `tech-distribution`, `lifecycle-kpi` |
| `alertType`, `alertStatus`, `owner`, `detectedTime` | `attention-queue` |

### Socket.io: Timer-Based → Ingestion-Driven

The POC uses `setInterval` to push `production-growth` and `monthly-cost` updates every 3–5 seconds with random jitter. The real pipeline replaces this:

1. Ingestion writer reports which fields were updated
2. If any updated field maps to a Socket.io-enabled widget, the cache is invalidated
3. The serving layer recomputes the widget data and pushes it to the subscribed Socket.io room
4. No polling, no jitter — real data changes drive real-time updates

### Scaling Path (If Needed Later)

If multiple server instances are needed behind a load balancer, replace the in-process LRU cache with Redis. The generator logic, invalidation mapping, and API contracts are unchanged. The Socket.io adapter switches to Redis pub/sub for cross-instance broadcasting.

---

## 8. API Changes

### Widget Endpoints — Internal Change Only

Routes stay at `GET /api/widgets/:type/data`. The only change is internal: handlers become `async` and read through the cache → generator → MongoDB pipeline chain. The response schema is identical. **No client changes.**

### Inventory Endpoint — Server-Side Pagination

At scale, `GET /api/inventory` can no longer return the full dataset. New query parameters:

```
GET /api/inventory?page=1&pageSize=10&lifecycleStage=POC&search=fraud&sortBy=useCaseName&sortOrder=asc
```

Response gains pagination metadata:

```json
{
  "data": [ "...AIUseCaseItem[]..." ],
  "meta": {
    "timestamp": "2026-03-22T10:00:00Z",
    "pagination": {
      "page": 1,
      "pageSize": 10,
      "totalItems": 487,
      "totalPages": 49
    }
  }
}
```

The `data` array schema is unchanged — same `AIUseCaseItem` shape. The `meta.pagination` object is additive.

### New Admin/Observability Endpoints

| Endpoint | Purpose |
|----------|---------|
| `GET /api/admin/ingestion/status` | Per-adapter health: last sync time, consecutive failures, circuit breaker state |
| `GET /api/admin/ingestion/logs` | Paginated audit logs with filtering by source, status, date range |
| `POST /api/admin/ingestion/:sourceId/trigger` | Manual trigger for a specific adapter (useful during onboarding and debugging) |
| `GET /api/admin/ingestion/unmapped` | Dead letter queue contents for manual ID resolution |

---

## 9. Client Impact

### What Changes

**`UseCasesTable.tsx`** — switches from client-side filtering/pagination to server-side. The component currently fetches all 110 items and filters in JavaScript. It must instead pass filter, search, sort, and pagination params to the API and render the returned page. The URL param state model (`useSearchParams`) is unchanged — params that previously drove local filtering now drive API query params.

**`UseCasesPage.tsx`** — may need to pass URL params through to the inventory API call, or `UseCasesTable` may manage its own data fetching (design decision for implementation).

### What Stays the Same

- **All widget components** — no changes. They call the same hooks with the same `dataSource` config
- **`useWidgetQuery` and `useWidgetSocket` hooks** — no changes to the hook API
- **`DashboardEngine`, `WidgetWrapper`, `WidgetRegistry`** — no changes
- **Dashboard configs** — no changes to the config schema or delivery mechanism
- **Widget → table navigation** — `buildUseCasesUrl()` and the URL param contract are unchanged
- **`UseCaseDetailPanel`** — no changes; it still receives an `AIUseCaseItem` and derives its sections

The frontend surface area affected is essentially one component and one page.

---

## 10. Migration & Rollout Strategy

### Phase 0: Seed Database from Mock Data

1. Run a seed script that takes the existing 110-item mock array, adds `_meta` (with a `"src-seed"` source), and inserts into the `useCases` collection
2. Verify: `db.useCases.countDocuments()` = 110
3. Run all 21 generators against the database and compare output to the current in-memory generators. **Output must be byte-identical.** This validates that the aggregation pipelines are correct translations of the in-memory operations

### Phase 1: Generator Migration (Behind Feature Flag)

1. Migrate generators from in-memory array operations to async MongoDB pipelines
2. Feature flag: `USE_DB_GENERATORS` — when `false`, the server uses the original mock generators. When `true`, it uses the database-backed generators
3. Run both in parallel in a test environment and diff the outputs continuously
4. Once validated, flip the flag in production. If anything breaks, flip it back — instant rollback to mock data

### Phase 2: Inventory Endpoint Migration

1. Add server-side pagination/filtering to `GET /api/inventory`
2. Feature flag: `USE_SERVER_PAGINATION` — when `false`, returns all items (existing behavior). When `true`, requires pagination params
3. Update `UseCasesTable.tsx` to work with server-side pagination
4. Validate: same filter/search/sort results as the client-side implementation

### Phase 3: Source Onboarding (One at a Time)

Onboarding order matters. Each source builds on the one before it:

| Order | Source | Why This Order |
|-------|--------|---------------|
| 1 | **Identity Registry** | Creates the core documents. All other sources update existing docs — they need the docs to exist first |
| 2 | **Governance API** | High-value fields (`status`, `severity`, `slaStatus`) that many widgets depend on |
| 3 | **Lifecycle Tracker** | `lifecycleStage` drives the most widgets (6 generators) |
| 4 | **Risk Platform** | Risk/compliance widgets are the second dashboard tab |
| 5 | **Model Monitor** (WebSocket) | First non-polling adapter — validates the WebSocket adapter pattern |
| 6 | **Finance System** (Excel) | First file-based adapter — validates the file watcher pattern |
| 7 | **Alert System** | Lowest widget dependency (only `attention-queue`) |

Each source is onboarded with:

1. **Dry-run mode** — adapter processes data and logs to `ingestionLogs` without writing to `useCases`. Validates field mapping and identity resolution
2. **Shadow mode** — adapter writes to `useCases` but behind a feature flag that prevents the serving layer from reading the new fields. Validates write path without affecting the dashboard
3. **Live mode** — feature flag flipped. New fields are live in the dashboard

### Rollback Plan

At every phase, the mock data layer remains intact. Feature flags allow instant reversion:

- Generator rollback: flip `USE_DB_GENERATORS` → back to in-memory mock generators
- Pagination rollback: flip `USE_SERVER_PAGINATION` → back to full-dataset response
- Source rollback: disable a specific adapter in `sourceConfigs` → its fields freeze at last known values (stale but valid)

---

## 11. Open Questions & Risks

### Open Questions

1. **What are the actual source system APIs?** This HLD uses placeholder names and assumed protocols. Each source will need a discovery phase to determine: authentication method, rate limits, response schema, available identifiers, and error behavior
2. **What ID does each source actually use?** The `idMappings` strategy is designed to handle heterogeneity, but we don't yet know the extent of the problem. If all sources happen to use `useCaseId`, the mapping layer simplifies dramatically
3. **Time-series data.** The POC uses static arrays for trend widgets (`model-performance`, `model-quality-risk`, `ai-index-trend`). Real time-series data requires either a separate collection with timestamped snapshots or an external time-series store. This is deferred to a later design
4. **Who operates the admin dashboard?** The ingestion health endpoints exist, but the UI for monitoring adapter health and resolving unmapped records is not scoped in this HLD
5. **Auth and access control.** The POC has no auth. The admin endpoints need access control before production use. Widget/table access control (e.g., restricting visibility by LOB) is a separate concern

### Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| **Source schemas are messier than expected** | High | Medium | Zod validation catches bad data. Dead letter queue catches unresolvable records. Dry-run mode validates before going live |
| **Identity resolution is harder than expected** | Medium | High | `idMappings` approach is flexible. Worst case: manual mapping spreadsheet maintained by the governance team |
| **Schema changes break generators** | Medium | Medium | Zod validation at ingestion + TypeScript types at compile time. Feature flags allow instant rollback |
| **Source system reliability** | High | Low | Circuit breakers prevent cascade failures. Stale data is surfaced with timestamps, not silently served |
| **Field ownership disputes** | Medium | Low | Conflict logging + admin visibility. Policy: most-recent-timestamp wins, disputes resolved by data governance team |
| **Performance at scale** | Low (at tens of thousands) | Medium | In-process cache handles 99% of reads. MongoDB aggregations are fast with proper indexes at this scale. Redis upgrade path is defined if needed |
